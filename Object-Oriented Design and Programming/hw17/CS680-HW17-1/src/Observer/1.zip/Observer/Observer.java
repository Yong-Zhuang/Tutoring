package Observer;

public interface Observer {

	public void update(Observable o, Object arg);

}
